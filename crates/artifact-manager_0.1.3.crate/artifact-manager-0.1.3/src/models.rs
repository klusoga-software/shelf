use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize)]
pub struct ArtifactConfig {
    pub plugin_config: PluginConfig,
}

#[derive(Serialize, Deserialize)]
pub enum Platform {
    Paper,
    Velocity,
    Waterfall,
}

#[derive(Serialize, Deserialize)]
pub struct PluginConfig {
    pub name: String,
    pub platform: Platform,
    pub version: String,
}

#[derive(Serialize, Deserialize, Debug)]
pub struct Plugin {
    pub name: String,
    pub version: String,
}

#[derive(Serialize, Deserialize, Debug)]
pub struct ServerConfig {
    pub path: String,
    pub base: String,
    pub plugins: Option<Vec<Plugin>>,
}
