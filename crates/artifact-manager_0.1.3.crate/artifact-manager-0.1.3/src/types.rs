use std::fmt::{Display, Formatter};

pub enum ArtifactType {
    Server,
    Backup,
    Plugin,
    Generic,
    Config,
}

impl Display for ArtifactType {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        match self {
            ArtifactType::Server => write!(f, "application/vnd.klusoga.redstone.server"),
            ArtifactType::Backup => write!(f, "application/vnd.klusoga.redstone.backup"),
            ArtifactType::Plugin => write!(f, "application/vnd.klusoga.redstone.plugin"),
            ArtifactType::Generic => write!(f, "application/vnd.klusoga.redstone.generic"),
            ArtifactType::Config => write!(f, "application/vnd.klusoga.redstone.config"),
        }
    }
}
