use crate::models::ArtifactConfig;
use crate::types::ArtifactType;
use oci_distribution::client::{Config, ImageLayer, PushResponse, TagResponse};
use oci_distribution::manifest::OciImageManifest;
use oci_distribution::secrets::RegistryAuth;
use oci_distribution::{Client, Reference};

pub struct ArtifactCreator {
    client: Client,
    auth: RegistryAuth,
}

fn walk_dir(path: String, layers: &mut Vec<ImageLayer>) -> Result<(), Box<dyn std::error::Error>> {
    for entry in std::fs::read_dir(path).unwrap() {
        let entry = entry?;

        if entry.file_type().unwrap().is_dir() {
            walk_dir(entry.path().to_str().unwrap().to_string(), layers)?
        } else {
            let data = std::fs::read(entry.path())?;

            let layer = ImageLayer::new(data, ArtifactType::Server.to_string(), None);
            layers.push(layer);
        }
    }

    Ok(())
}

impl ArtifactCreator {
    pub fn new(client: Client, auth: RegistryAuth) -> Self {
        Self { client, auth }
    }

    /// Push a directory reference with an optional config to a oci registry
    ///
    /// # Arguments
    ///
    /// * `path`: The path to the directory you want to push
    /// * `reference`: The reference of an oci image
    /// * `artifact_config`: The optional artifact config
    ///
    /// returns: Result<PushResponse, Box<dyn Error, Global>>
    ///
    /// # Examples
    ///
    /// ```
    ///  
    /// ```
    pub async fn push(
        &self,
        path: String,
        reference: Reference,
        artifact_config: Option<ArtifactConfig>,
    ) -> Result<PushResponse, Box<dyn std::error::Error>> {
        let mut layers: Vec<ImageLayer> = Vec::new();

        let _ = walk_dir(path, &mut layers);

        let config: Config = if artifact_config.is_some() {
            Config {
                data: serde_json::to_string(&artifact_config)?.into(),
                media_type: ArtifactType::Config.to_string(),
                annotations: None,
            }
        } else {
            Config {
                data: b"{}".to_vec(),
                media_type: ArtifactType::Config.to_string(),
                annotations: None,
            }
        };

        let image_manifest = OciImageManifest::build(&layers, &config, None);

        let response = match self
            .client
            .push(
                &reference,
                &layers,
                config,
                &self.auth,
                Some(image_manifest),
            )
            .await
        {
            Ok(response) => response,
            Err(err) => return Err(err.into()),
        };

        Ok(response)
    }

    /// Fetches a manifest and a comfig for a image reference
    ///
    /// # Arguments
    ///
    /// * `reference`: The oci image reference you want to push
    ///
    /// returns: Result<(OciImageManifest, String, String), OciDistributionError>
    ///
    /// # Examples
    ///
    /// ```
    ///
    /// ```
    pub async fn fetch_manifest(
        &self,
        reference: Reference,
    ) -> oci_distribution::errors::Result<(OciImageManifest, String, String)> {
        self.client
            .pull_manifest_and_config(&reference, &self.auth)
            .await
    }

    /// Receive all tags for a reference
    ///
    /// # Arguments
    ///
    /// * `reference`: The oci image reference you want to push
    ///
    /// returns: Result<TagResponse, OciDistributionError>
    ///
    /// # Examples
    ///
    /// ```
    ///
    /// ```
    pub async fn list_tags(
        &self,
        reference: Reference,
    ) -> oci_distribution::errors::Result<TagResponse> {
        self.client
            .list_tags(&reference, &self.auth, None, None)
            .await
    }
}

#[cfg(test)]
mod tests {
    use crate::artifact_creator::ArtifactCreator;
    use crate::models::{ArtifactConfig, Platform, PluginConfig};
    use oci_distribution::client::{ClientConfig, ClientProtocol};
    use oci_distribution::secrets::RegistryAuth;
    use oci_distribution::{Client, Reference};
    use std::str::FromStr;
    use std::time::Duration;
    use testcontainers::core::WaitFor;
    use testcontainers::runners::AsyncRunner;
    use testcontainers::{ContainerAsync, GenericImage};

    async fn create_registry() -> ContainerAsync<GenericImage> {
        GenericImage::new("registry", "latest")
            .with_exposed_port(5000.into())
            .with_wait_for(WaitFor::Duration {
                length: Duration::from_secs(15),
            })
            .start()
            .await
            .expect("Failed to start image")
    }

    #[tokio::test]
    async fn test_push() {
        let registry = create_registry().await;

        let af = ArtifactCreator::new(
            Client::new(ClientConfig {
                protocol: ClientProtocol::Http,
                ..Default::default()
            }),
            RegistryAuth::Anonymous,
        );

        let port = registry.get_host_port_ipv4(5000).await.unwrap();

        let result = af
            .push(
                "test".to_string(),
                Reference::with_tag(
                    format!("localhost:{port}"),
                    "mc".to_string(),
                    "latest".to_string(),
                ),
                None,
            )
            .await;

        assert!(result.is_ok());
    }

    #[tokio::test]
    async fn test_push_with_config() {
        let registry = create_registry().await;
        let af = ArtifactCreator::new(
            Client::new(ClientConfig {
                protocol: ClientProtocol::Http,
                ..Default::default()
            }),
            RegistryAuth::Anonymous,
        );

        let port = registry.get_host_port_ipv4(5000).await.unwrap();

        let result = af
            .push(
                "test".to_string(),
                Reference::with_tag(
                    format!("localhost:{port}"),
                    "mc".to_string(),
                    "latest".to_string(),
                ),
                Some(ArtifactConfig {
                    plugin_config: PluginConfig {
                        name: "test".to_string(),
                        platform: Platform::Paper,
                        version: ">=1.20".to_string(),
                    },
                }),
            )
            .await;

        assert!(result.is_ok());
    }

    #[tokio::test]
    async fn test_fetch_tags() {
        let registry = create_registry().await;
        let af = ArtifactCreator::new(
            Client::new(ClientConfig {
                protocol: ClientProtocol::Http,
                ..Default::default()
            }),
            RegistryAuth::Anonymous,
        );

        let port = registry.get_host_port_ipv4(5000).await.unwrap();

        let _result = af
            .push(
                "test".to_string(),
                Reference::with_tag(
                    format!("localhost:{port}"),
                    "mc".to_string(),
                    "latest".to_string(),
                ),
                Some(ArtifactConfig {
                    plugin_config: PluginConfig {
                        name: "test".to_string(),
                        platform: Platform::Paper,
                        version: ">=1.20".to_string(),
                    },
                }),
            )
            .await;

        let result = af
            .list_tags(Reference::from_str(format!("localhost:{}/mc", port).as_str()).unwrap())
            .await;

        assert!(result.is_ok());
        assert_eq!(result.unwrap().tags.len(), 1)
    }

    #[tokio::test]
    async fn test_pull_manifest_config() {
        let registry = create_registry().await;

        let af = ArtifactCreator::new(
            Client::new(ClientConfig {
                protocol: ClientProtocol::Http,
                ..Default::default()
            }),
            RegistryAuth::Anonymous,
        );

        let port = registry.get_host_port_ipv4(5000).await.unwrap();

        let result = af
            .push(
                "test".to_string(),
                Reference::with_tag(
                    format!("localhost:{port}"),
                    "mc".to_string(),
                    "latest".to_string(),
                ),
                Some(ArtifactConfig {
                    plugin_config: PluginConfig {
                        name: "test".to_string(),
                        platform: Platform::Paper,
                        version: ">=1.20".to_string(),
                    },
                }),
            )
            .await;

        assert!(result.is_ok());

        let result = af
            .fetch_manifest(Reference::with_tag(
                format!("localhost:{port}"),
                "mc".to_string(),
                "latest".to_string(),
            ))
            .await;

        assert!(result.is_ok());

        let (_, _, s2) = result.unwrap();
        assert_eq!(
            s2,
            "{\"plugin_config\":{\"name\":\"test\",\"platform\":\"Paper\",\"version\":\">=1.20\"}}"
        )
    }
}
