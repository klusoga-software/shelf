use crate::models::ServerConfig;
use reqwest::Client;
use std::fs::File;
use std::io;
use std::io::{copy, Write};
use std::path::Path;

#[derive(Default)]
pub struct ServerCreator {
    pub client: Client,
}

impl ServerCreator {
    pub fn new(client: Client) -> Self {
        Self { client }
    }
    pub async fn create_server<'a>(
        &self,
        config: ServerConfig,
    ) -> Result<(), Box<dyn std::error::Error>> {
        let server_path: &'a str = format!("{}/server.jar", config.path.clone()).leak();
        let eula_path: &'a str = format!("{}/eula.txt", config.path.clone()).leak();

        let base_dir_exists = Path::new(config.path.as_str()).exists();
        let server_file_exists = Path::new(server_path).exists();
        let eula_exists = Path::new(eula_path).exists();

        if !base_dir_exists {
            std::fs::create_dir(config.path.clone())?;
        }

        if !server_file_exists {
            let mut server_file = File::create(server_path)?;

            let server_base_download = self.client.get(config.base).send().await?;
            let mut content = io::Cursor::new(server_base_download.bytes().await?);
            copy(&mut content, &mut server_file)?;
        }

        if !eula_exists {
            let mut eula_file = File::create(eula_path)?;
            eula_file.write_all(b"eula=true")?;
        }

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use crate::models::ServerConfig;
    use crate::server_creator::ServerCreator;
    use log::error;

    #[tokio::test]
    async fn test_create_server() {
        env_logger::try_init().unwrap();

        let sc = ServerCreator::default();

        match sc.create_server(ServerConfig{
            base: "https://api.papermc.io/v2/projects/paper/versions/1.21.1/builds/85/downloads/paper-1.21.1-85.jar".to_string(),
            path: "test".to_string(),
            plugins: None
        }).await {
            Ok(_) => {}
            Err(err) => {
                error!("{}", err)
            }
        };
    }
}
